#pragma once
#include "Scene.h"

void init_gravity_test(scene* s_to_init);
