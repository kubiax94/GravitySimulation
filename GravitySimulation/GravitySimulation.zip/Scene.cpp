#include "Scene.h"

scene_node* scene::create_scene_node(const std::string& n_name) {
	auto* node = new scene_node(n_name, nullptr, this);
	root_->add_child(node);
	return node;
}

scene_node* scene::find_scene_node(const std::string& n_name) const {
	const auto f_nodes = root_->find_node<scene_node>(n_name, search_options::recursive_down);
	return f_nodes.empty() ? nullptr : f_nodes.front();
}

void scene::register_in(component* comp) {
	type_id_t type_id = comp->get_type_id();

	switch () {  }
}

void scene::register_out(component* comp) {
}

void scene::add_to_scene(scene_node* n_node) const {
	root_->add_child(n_node);
}

void scene::init() {
}

void scene::update() {
	root_->update();
}

void scene::draw() {
	root_->draw();
}
