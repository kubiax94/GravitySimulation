﻿#include "rigid_body.h"

rigid_body::rigid_body(scene_node* owner, const physics_data& p_data) : component(owner), physics_data(p_data) {
	
}

type_id_t rigid_body::get_type_id() const {
	return ::get_type_id<rigid_body>();
}

void rigid_body::attach_to(scene_node* n_node) {
	component::attach_to(n_node);

	if (auto* s_manager = owner_node_->get_scene_manager())
		s_manager->register_in(this);
	
}

bool rigid_body::detach() {
	bool d_cond = component::detach();
	if (auto* s_manager = owner_node_->get_scene_manager())
		s_manager->register_in(this);

	return d_cond;
}

rigid_body::~rigid_body() {
}
