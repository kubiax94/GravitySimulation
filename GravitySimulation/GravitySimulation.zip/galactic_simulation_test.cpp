#include "galactic_simulation_test.h"

#include "Mesh.h"
#include "Shape.h"
#include "renderer.h"

struct planet_data
{
	std::string name;
	float mass = 0.f;
	float diameter = 0.f;
	float distance_to_sun = 0.f;
};
namespace sim {

	std::vector<planet_data> data = {
	{"Mercury", 0.330e24f, 4879, 57.9e6f},
	{"Venus", 4.87e24f, 12104, 108.2e6f},
	{"Earth", 5.97e24f, 12756, 149.6e6f},
	{"Mars", 0.642e24f, 6792, 227.9e6f},
	{"Jupiter", 1898e24f, 142984, 778.6e6f},
	{"Saturn", 568e24f, 120536, 1433.5e6f},
	{"Uranus", 86.8e24f, 51118, 2872.5e6f},
	{"Neptune", 102e24f, 49528, 4495.1e6f}
	};


	void init_gravity_test(scene* s_to_init) {

		auto* sun_node = s_to_init->create_scene_node("Sun");
		shader* planet_shader = new shader("C:/Users/Kubiaxx/source/repos/GravitySimulation/GravitySimulation/camera.vs.shader", "C:/Users/Kubiaxx/source/repos/GravitySimulation/GravitySimulation/camera.fs.shader");
		shader* sun_shader = new shader("C:/Users/Kubiaxx/source/repos/GravitySimulation/GravitySimulation/lightsource.vs.shader", "C:/Users/Kubiaxx/source/repos/GravitySimulation/GravitySimulation/sun.fs.shader");

		auto sphere_mesh_data = Shape::GenerateSphere();
		auto* sphere_mesh = new Mesh(sphere_mesh_data);

		sun_node->add_component<renderer>(sun_node, sun_shader, sphere_mesh);
		

	}
}